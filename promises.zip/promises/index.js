// function getRandomNumber() {
//     return new Promise(resolve => {
//       setTimeout(() => {
//         resolve(Math.random());
//       }, 500);
//     });
//   }
  
//   async function plzWork() {
//     console.log("do this first")
//     const result = await getRandomNumber();
//     console.log(result);
//   }
  
//   plzWork();
  

  const getRandomNumber = () => new Promise(resolve => {
        setTimeout(() => {
          resolve(Math.random());
        }, 500);
      });
  

  async function theInvoke() {
    console.log("do this first")
    const result = await getRandomNumber();
    console.log(result);
  }
  
  theInvoke();
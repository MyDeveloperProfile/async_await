// These are three ways to write functions

// 1st way. This is called a function declaration. 
// You could overwrite your function using this method. 
// !!!!!This method alos allows hoisting, which means 
// we can run this function block and the bottom 
// of our script and still write our code to invoke it anywhere 
// in our code. !!!!!Essentiall th function can come after we invoke it

function nameGiven() {}





// 2nd way
// The two following functions are called 
// function expressions. When you use a varibale and assign it to a
// function you wont overwrite your funnction. It will stay the same.
// !!!!We are storing a function inside a variable using this method.
// !!! You cannot hoist with this method.

const nameGiven = function () {};

// 3rd and most modern way (same as above)

const nameGiven = () => {};


// This is how to invoke your function... by using the name of the 
// const

nameGiven();




